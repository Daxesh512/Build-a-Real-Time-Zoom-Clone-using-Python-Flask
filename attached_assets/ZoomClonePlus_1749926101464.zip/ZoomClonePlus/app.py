from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from flask_socketio import SocketIO, emit, join_room, leave_room
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import uuid
import os

# Create Flask app
app = Flask(__name__)
app.config['SECRET_KEY'] = 'zoomclone-secret-key-2024'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///zoomclone.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize extensions
db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
socketio = SocketIO(app, cors_allowed_origins="*")

# Database Models
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(120), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Meeting(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    meeting_id = db.Column(db.String(36), unique=True, nullable=False, default=lambda: str(uuid.uuid4()))
    title = db.Column(db.String(200), nullable=False)
    host_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=False)
    
    host = db.relationship('User', backref='hosted_meetings')

class ChatMessage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    meeting_id = db.Column(db.String(36), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    username = db.Column(db.String(80), nullable=False)
    message = db.Column(db.Text, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    
    user = db.relationship('User')

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        
        if User.query.filter_by(username=username).first():
            flash('Username already exists')
            return render_template('register.html')
        
        if User.query.filter_by(email=email).first():
            flash('Email already registered')
            return render_template('register.html')
        
        user = User(username=username, email=email)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        
        flash('Registration successful')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        
        if user and user.check_password(password):
            login_user(user)
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    meetings = Meeting.query.filter_by(host_id=current_user.id).order_by(Meeting.created_at.desc()).all()
    return render_template('dashboard.html', meetings=meetings)

@app.route('/create-meeting', methods=['POST'])
@login_required
def create_meeting():
    title = request.form.get('title', 'Quick Meeting')
    meeting = Meeting(title=title, host_id=current_user.id)
    db.session.add(meeting)
    db.session.commit()
    return redirect(url_for('meeting', meeting_id=meeting.meeting_id))

@app.route('/join', methods=['GET', 'POST'])
def join():
    if request.method == 'POST':
        meeting_id = request.form['meeting_id'].strip()
        meeting = Meeting.query.filter_by(meeting_id=meeting_id).first()
        if meeting:
            if current_user.is_authenticated:
                return redirect(url_for('meeting', meeting_id=meeting_id))
            else:
                return redirect(url_for('login'))
        else:
            flash('Meeting not found')
    return render_template('join.html')

@app.route('/meeting/<meeting_id>')
@login_required
def meeting(meeting_id):
    meeting = Meeting.query.filter_by(meeting_id=meeting_id).first()
    if not meeting:
        flash('Meeting not found')
        return redirect(url_for('dashboard'))
    
    # Activate meeting if host joins
    if meeting.host_id == current_user.id and not meeting.is_active:
        meeting.is_active = True
        db.session.commit()
    
    messages = ChatMessage.query.filter_by(meeting_id=meeting_id).order_by(ChatMessage.timestamp.asc()).all()
    return render_template('meeting.html', meeting=meeting, messages=messages)

# Socket Events
@socketio.on('connect')
def on_connect():
    if current_user.is_authenticated:
        print(f'User {current_user.username} connected')

@socketio.on('disconnect')
def on_disconnect():
    if current_user.is_authenticated:
        print(f'User {current_user.username} disconnected')

@socketio.on('join_meeting')
def on_join_meeting(data):
    if not current_user.is_authenticated:
        return
    
    meeting_id = data['meeting_id']
    join_room(meeting_id)
    
    emit('user_joined', {
        'user_id': current_user.id,
        'username': current_user.username
    }, room=meeting_id, include_self=False)

@socketio.on('leave_meeting')
def on_leave_meeting(data):
    if not current_user.is_authenticated:
        return
    
    meeting_id = data['meeting_id']
    leave_room(meeting_id)
    
    emit('user_left', {
        'user_id': current_user.id,
        'username': current_user.username
    }, room=meeting_id, include_self=False)

@socketio.on('send_message')
def on_send_message(data):
    if not current_user.is_authenticated:
        return
    
    meeting_id = data['meeting_id']
    message_text = data['message']
    
    # Save message to database
    message = ChatMessage(
        meeting_id=meeting_id,
        user_id=current_user.id,
        username=current_user.username,
        message=message_text
    )
    db.session.add(message)
    db.session.commit()
    
    # Broadcast message
    emit('new_message', {
        'user_id': current_user.id,
        'username': current_user.username,
        'message': message_text,
        'timestamp': message.timestamp.strftime('%H:%M')
    }, room=meeting_id)

# WebRTC Signaling
@socketio.on('webrtc_offer')
def handle_webrtc_offer(data):
    if not current_user.is_authenticated:
        return
    
    emit('webrtc_offer', {
        'from_user_id': current_user.id,
        'from_username': current_user.username,
        'offer': data['offer']
    }, room=data['meeting_id'], include_self=False)

@socketio.on('webrtc_answer')
def handle_webrtc_answer(data):
    if not current_user.is_authenticated:
        return
    
    emit('webrtc_answer', {
        'from_user_id': current_user.id,
        'from_username': current_user.username,
        'answer': data['answer']
    }, room=data['meeting_id'], include_self=False)

@socketio.on('webrtc_ice_candidate')
def handle_ice_candidate(data):
    if not current_user.is_authenticated:
        return
    
    emit('webrtc_ice_candidate', {
        'from_user_id': current_user.id,
        'candidate': data['candidate']
    }, room=data['meeting_id'], include_self=False)

@socketio.on('toggle_audio')
def on_toggle_audio(data):
    if not current_user.is_authenticated:
        return
    
    emit('audio_toggled', {
        'user_id': current_user.id,
        'is_muted': data['is_muted']
    }, room=data['meeting_id'], include_self=False)

@socketio.on('toggle_video')
def on_toggle_video(data):
    if not current_user.is_authenticated:
        return
    
    emit('video_toggled', {
        'user_id': current_user.id,
        'is_video_on': data['is_video_on']
    }, room=data['meeting_id'], include_self=False)

@socketio.on('screen_share_start')
def on_screen_share_start(data):
    if not current_user.is_authenticated:
        return
    
    emit('screen_share_started', {
        'user_id': current_user.id,
        'username': current_user.username
    }, room=data['meeting_id'], include_self=False)

@socketio.on('screen_share_stop')
def on_screen_share_stop(data):
    if not current_user.is_authenticated:
        return
    
    emit('screen_share_stopped', {
        'user_id': current_user.id,
        'username': current_user.username
    }, room=data['meeting_id'], include_self=False)

@socketio.on('admin_mute_user')
def on_admin_mute_user(data):
    if not current_user.is_authenticated:
        return
    
    meeting = Meeting.query.filter_by(meeting_id=data['meeting_id']).first()
    if meeting and meeting.host_id == current_user.id:
        emit('user_muted_by_admin', {
            'user_id': data['user_id'],
            'admin': current_user.username
        }, room=data['meeting_id'])

@socketio.on('admin_kick_user')
def on_admin_kick_user(data):
    if not current_user.is_authenticated:
        return
    
    meeting = Meeting.query.filter_by(meeting_id=data['meeting_id']).first()
    if meeting and meeting.host_id == current_user.id:
        emit('user_kicked', {
            'user_id': data['user_id'],
            'admin': current_user.username
        }, room=data['meeting_id'])

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    socketio.run(app, host='127.0.0.1', port=5000, debug=True)
# ZoomClone Video Conferencing Application

## Overview

ZoomClone is a video conferencing web application built with Flask and Socket.IO. It provides essential video meeting functionality including user authentication, meeting creation/joining, real-time communication, and basic meeting management features.

## System Architecture

The application follows a traditional Flask web application architecture with real-time capabilities:

- **Backend Framework**: Flask with SQLAlchemy ORM
- **Real-time Communication**: Flask-SocketIO for WebSocket connections
- **Authentication**: Flask-Login for session management
- **Database**: SQLite (development), PostgreSQL (production via environment)
- **Frontend**: Server-side rendered HTML templates with Bootstrap UI
- **Deployment**: Gunicorn WSGI server with autoscale deployment

## Key Components

### Backend Components

1. **Application Factory** (`app.py`)
   - Centralizes Flask app configuration
   - Initializes extensions (SQLAlchemy, Flask-Login, SocketIO)
   - Configures database connection with connection pooling
   - Sets up proxy middleware for deployment

2. **Data Models** (`models.py`)
   - `User`: Authentication and user management
   - `Meeting`: Meeting metadata and configuration
   - `MeetingParticipant`: Join table for meeting participation (incomplete)
   - Uses Flask-Login's UserMixin for authentication integration

3. **HTTP Routes** (`routes.py`)
   - Authentication routes (login, register, logout)
   - Meeting management (create, join, dashboard)
   - Template rendering for all UI pages

4. **WebSocket Events** (`socket_events.py`)
   - Real-time meeting events (join, leave, disconnect)
   - Participant management and room-based communication
   - Integration with database for persistent state

5. **Utilities** (`utils.py`)
   - Meeting ID generation and validation
   - URL generation and email validation helpers
   - File handling utilities (sanitization)

### Frontend Components

1. **Templates** (`templates/`)
   - Base template with Bootstrap integration
   - Authentication pages (login, register)
   - Meeting interfaces (dashboard, meeting room, join)
   - Responsive design with modern UI components

2. **Static Assets** (`static/`)
   - CSS: Modern styling with CSS custom properties
   - JavaScript: Meeting room functionality and Socket.IO client
   - Modular JS architecture for different features

### Database Schema

- **Users**: Authentication with password hashing
- **Meetings**: UUID-based meeting IDs with host relationship
- **Meeting Participants**: Tracks user participation in meetings
- **Chat Messages**: Persistent meeting chat (referenced but not fully implemented)

## Data Flow

1. **Authentication Flow**
   - User registration/login via HTTP forms
   - Session management through Flask-Login
   - Password hashing with Werkzeug utilities

2. **Meeting Creation**
   - HTTP POST to create meeting with generated UUID
   - Database persistence of meeting metadata
   - Redirect to meeting room interface

3. **Meeting Joining**
   - WebSocket connection establishment
   - Room-based communication via Socket.IO
   - Real-time participant updates

4. **Real-time Communication**
   - Socket.IO for bidirectional communication
   - Room-based event broadcasting
   - Integration with database for persistent state

## External Dependencies

### Python Packages
- **Flask**: Web framework and HTTP handling
- **Flask-SQLAlchemy**: ORM and database abstraction
- **Flask-Login**: Authentication and session management
- **Flask-SocketIO**: WebSocket support for real-time features
- **Gunicorn**: Production WSGI server
- **psycopg2-binary**: PostgreSQL adapter for production

### Frontend Libraries
- **Bootstrap 5**: UI framework and responsive design
- **Font Awesome**: Icon library
- **Socket.IO Client**: Real-time communication from browser

### Infrastructure
- **PostgreSQL**: Production database (configured via environment)
- **SQLite**: Development database fallback
- **Replit Nix**: Package management and system dependencies

## Deployment Strategy

The application is configured for Replit's autoscale deployment:

- **Production Server**: Gunicorn with multiple worker processes
- **Port Configuration**: Binds to 0.0.0.0:5000 with port reuse
- **Database**: Environment-based configuration for PostgreSQL
- **Static Files**: Served directly by Flask in development
- **WebSocket Transport**: Supports both WebSocket and polling fallbacks

The deployment uses Nix for package management, ensuring consistent environments across development and production. The application includes proxy middleware for proper header handling in deployed environments.

## User Preferences

Preferred communication style: Simple, everyday language.

## Changelog

Changelog:
- June 14, 2025. Initial setup